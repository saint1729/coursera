package com.example.sharingapp;

import java.util.UUID;

public class Contact {

    public Contact(String username, String email, String id ) {
        this.username = username;
        this.email = email;
        if (id == null) {
            setId();
        } else {
            updateId(id);
        }
    }

    private String username;
    private String email;
    private String id;

    // Setter method for Id
    public void setId() {
        this.id = UUID.randomUUID().toString();
    }

    // Getter method for Id
    public String getId() {
        return this.id;
    }

    // Update the id - method
    public void updateId(String id) {
        this.id = id;
    }

    // Setter for username
    public void setUsername(String username) {
        this.username = username;
    }

    // Getter for username
    public String getUsername() {
        return this.username;
    }

    // Setter - email
    public void setEmail(String email) {
        this.email = email;
    }

    //Getter - email
    public String getEmail() {
        return this.email;
    }

}
