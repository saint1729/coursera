# Uses python3
import sys

def get_change(n):
    #write your code here
    return n

if __name__ == '__main__':
    n = int(sys.stdin.read())
    print(get_change(n))
